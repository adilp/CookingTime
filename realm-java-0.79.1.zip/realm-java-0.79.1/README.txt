Realm for Android
=================
This is a beta release of Realm for Android.

Getting Started
---------------
Please check the documentation on http://realm.io/docs/java for how to get started.

Examples
--------
Included in this distribution are a couple of examples.
You can try them out from Android Studio through "File->Import Project" and selecting the
build.gradle file in the respective example. Then click "Run".
But more importantly check out the source code in RealmIntroExample/app/src
which will provide examples for how to use the API.

Feedback
--------
We highly appreciate your feedback to make Realm  awesome!
Please send your feedback to https://groups.google.com/forum/#!forum/realm-java

Thanks!
The Realm team
